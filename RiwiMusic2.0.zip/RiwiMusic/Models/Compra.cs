﻿namespace RiwiMusic;

public class Compra
{
    public int id { get; set; }
    public int idCliente { get; set; }
    public int idConcierto { get; set; }
    public int cantidadTiquetes { get; set; }
    public DateTime fechaCompra { get; set; }
}