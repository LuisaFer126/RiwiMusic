﻿namespace RiwiMusic;

public class Cliente
{
    public int id { get; set; }
    public string nombre { get; set; }
    public string identificacion { get; set; }
    public string email { get; set; }
    public string telefono { get; set; }
}