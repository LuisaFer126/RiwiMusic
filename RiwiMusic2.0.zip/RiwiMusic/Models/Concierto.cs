﻿namespace RiwiMusic;

public class Concierto
{
    public int id { get; set; }
    public int idAdmin { get; set; }
    public string nombre { get; set; }
    public string ciudad { get; set; }
    public DateTime fechaConcierto { get; set; }
    public int precio { get; set; } // Agregado para el cálculo de ingresos
}