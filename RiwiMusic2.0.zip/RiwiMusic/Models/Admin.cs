﻿namespace RiwiMusic;

public class Admin
{
    public int id { get; set; }
    public string nombre { get; set; }
    public string identificacion { get; set; }
}