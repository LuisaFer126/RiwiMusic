﻿namespace RiwiMusic;
using System;
using System.Collections.Generic;
using System.Linq;

public class Program
{
	// Listas para almacenar los datos
	public static List<Admin> admins = new List<Admin>();
	public static List<Concierto> conciertos = new List<Concierto>();
	public static List<Cliente> clientes = new List<Cliente>();
	public static List<Compra> compras = new List<Compra>();

	// Contadores para IDs automáticos
	public static int conciertoIdCounter = 1;
	public static int clienteIdCounter = 1;
	public static int compraIdCounter = 1;
	
	public static void Main()
	{
		// Se pueden agregar datos iniciales para probar
		conciertos.Add(new Concierto { id = conciertoIdCounter++, nombre = "Concierto Rock", ciudad = "Medellin", fechaConcierto = new DateTime(2025, 10, 20), precio = 50 });
		conciertos.Add(new Concierto { id = conciertoIdCounter++, nombre = "Festival de Jazz", ciudad = "Bogota", fechaConcierto = new DateTime(2025, 11, 15), precio = 75 });
		conciertos.Add(new Concierto { id = conciertoIdCounter++, nombre = "Electrónica Noche", ciudad = "Medellin", fechaConcierto = new DateTime(2025, 12, 1), precio = 60 });
        
		clientes.Add(new Cliente { id = clienteIdCounter++, nombre = "Carlos Perez", identificacion = "12345", email = "carlos@mail.com", telefono = "3001234567" });
		clientes.Add(new Cliente { id = clienteIdCounter++, nombre = "Maria Gomez", identificacion = "67890", email = "maria@mail.com", telefono = "3109876543" });

		bool salir = false;
		while (!salir)
		{
			MostrarMenuPrincipal();
			string opcion = Console.ReadLine();

			switch (opcion)
			{
				case "1":
					GestionConciertos();
					break;
				case "2":
					GestionClientes();
					break;
				case "3":
					GestionTiquetes();
					break;
				case "4":
					MostrarHistorialCompras();
					break;
				case "5":
					ConsultasAvanzadas();
					break;
				case "6":
					salir = true;
					Console.WriteLine("Saliendo del sistema...");
					break;
				default:
					Console.WriteLine("Opción no válida. Intenta de nuevo.");
					break;
			}
			Console.WriteLine("\nPresiona Enter para continuar...");
			Console.ReadLine();
		}
	}
	public static void MostrarMenuPrincipal()
	{
		Console.Clear();
		Console.WriteLine("--- RIWIMUSIC - SISTEMA DE GESTIÓN ---");
		Console.WriteLine("1. Gestión de Conciertos");
		Console.WriteLine("2. Gestión de Clientes");
		Console.WriteLine("3. Gestión de Tiquetes");
		Console.WriteLine("4. Historial de Compras");
		Console.WriteLine("5. Consultas Avanzadas (LINQ)");
		Console.WriteLine("6. Salir");
		Console.Write("Selecciona una opción: ");
	}
    
	// Métodos para cada opción del menú principal
	public static void GestionConciertos()
	{
		Console.Clear();
		Console.WriteLine("--- GESTIÓN DE CONCIERTOS ---");
		Console.WriteLine("1. Registrar concierto");
		Console.WriteLine("2. Listar conciertos");
		Console.WriteLine("3. Editar concierto");
		Console.WriteLine("4. Eliminar concierto");
		Console.Write("Selecciona una opción: ");
		string opcion = Console.ReadLine();
        
		switch (opcion)
		{
			case "1":
				RegistrarConcierto();
				break;
			case "2":
				ListarConciertos();
				break;
			case "3":
				EditarConcierto();
				break;
			case "4":
				EliminarConcierto();
				break;
			default:
				Console.WriteLine("Opción no válida.");
				break;
		}
	}
	
	public static void RegistrarConcierto()
    {
        Console.WriteLine("--- REGISTRO DE CONCIERTO ---");
        var nuevoConcierto = new Concierto();
        nuevoConcierto.id = conciertoIdCounter++;
        
        Console.Write("Nombre del concierto: ");
        nuevoConcierto.nombre = Console.ReadLine();
        
        Console.Write("Ciudad del concierto: ");
        nuevoConcierto.ciudad = Console.ReadLine();
        
        Console.Write("Fecha del concierto (yyyy-MM-dd): ");
        DateTime fecha;
        while (!DateTime.TryParse(Console.ReadLine(), out fecha))
        {
            Console.WriteLine("Formato de fecha no válido. Intenta de nuevo (yyyy-MM-dd): ");
        }
        nuevoConcierto.fechaConcierto = fecha;
        
        Console.Write("Precio del tiquete: ");
        int precio;
        while (!int.TryParse(Console.ReadLine(), out precio) || precio <= 0)
        {
            Console.WriteLine("Precio no válido. Debe ser un número entero positivo: ");
        }
        nuevoConcierto.precio = precio;
        
        conciertos.Add(nuevoConcierto);
        Console.WriteLine("Concierto registrado exitosamente.");
    }

    public static void ListarConciertos()
    {
        Console.WriteLine("--- LISTA DE CONCIERTOS ---");
        if (conciertos.Count == 0)
        {
            Console.WriteLine("No hay conciertos registrados.");
            return;
        }
        foreach (var concierto in conciertos)
        {
            Console.WriteLine($"ID: {concierto.id}, Nombre: {concierto.nombre}, Ciudad: {concierto.ciudad}, Fecha: {concierto.fechaConcierto.ToShortDateString()}, Precio: ${concierto.precio}");
        }
    }
    
    public static void EditarConcierto()
    {
        Console.Write("Ingresa el ID del concierto a editar: ");
        if (int.TryParse(Console.ReadLine(), out int id))
        {
            var conciertoAEditar = conciertos.FirstOrDefault(c => c.id == id);
            if (conciertoAEditar != null)
            {
                Console.WriteLine($"Editando: {conciertoAEditar.nombre}");
                Console.Write("Nuevo nombre (dejar en blanco para no cambiar): ");
                string nuevoNombre = Console.ReadLine();
                if (!string.IsNullOrEmpty(nuevoNombre))
                {
                    conciertoAEditar.nombre = nuevoNombre;
                }
                
                Console.Write("Nueva ciudad (dejar en blanco para no cambiar): ");
                string nuevaCiudad = Console.ReadLine();
                if (!string.IsNullOrEmpty(nuevaCiudad))
                {
                    conciertoAEditar.ciudad = nuevaCiudad;
                }
                
                Console.Write("Nueva fecha (yyyy-MM-dd, dejar en blanco para no cambiar): ");
                string nuevaFechaStr = Console.ReadLine();
                if (!string.IsNullOrEmpty(nuevaFechaStr))
                {
                    if (DateTime.TryParse(nuevaFechaStr, out DateTime nuevaFecha))
                    {
                        conciertoAEditar.fechaConcierto = nuevaFecha;
                    }
                    else
                    {
                        Console.WriteLine("Formato de fecha no válido, no se cambió la fecha.");
                    }
                }
                
                Console.WriteLine("Concierto actualizado exitosamente.");
            }
            else
            {
                Console.WriteLine("Concierto no encontrado.");
            }
        }
        else
        {
            Console.WriteLine("ID no válido.");
        }
    }
    
    public static void EliminarConcierto()
    {
        Console.Write("Ingresa el ID del concierto a eliminar: ");
        if (int.TryParse(Console.ReadLine(), out int id))
        {
            var conciertoAEliminar = conciertos.FirstOrDefault(c => c.id == id);
            if (conciertoAEliminar != null)
            {
                conciertos.Remove(conciertoAEliminar);
                Console.WriteLine("Concierto eliminado exitosamente.");
            }
            else
            {
                Console.WriteLine("Concierto no encontrado.");
            }
        }
        else
        {
            Console.WriteLine("ID no válido.");
        }
    }
    
    public static void GestionClientes()
    {
        Console.Clear();
        Console.WriteLine("--- GESTIÓN DE CLIENTES ---");
        Console.WriteLine("1. Registrar cliente");
        Console.WriteLine("2. Listar clientes");
        Console.WriteLine("3. Editar cliente");
        Console.WriteLine("4. Eliminar cliente");
        Console.Write("Selecciona una opción: ");
        string opcion = Console.ReadLine();
        
        switch (opcion)
        {
            case "1":
                RegistrarCliente();
                break;
            case "2":
                ListarClientes();
                break;
            case "3":
                EditarCliente();
                break;
            case "4":
                EliminarCliente();
                break;
            default:
                Console.WriteLine("Opción no válida.");
                break;
        }
    }
    
    public static void RegistrarCliente()
    {
        Console.WriteLine("--- REGISTRO DE CLIENTE ---");
        var nuevoCliente = new Cliente();
        nuevoCliente.id = clienteIdCounter++;
        
        Console.Write("Nombre del cliente: ");
        nuevoCliente.nombre = Console.ReadLine();
        
        Console.Write("Identificación: ");
        nuevoCliente.identificacion = Console.ReadLine();
        
        Console.Write("Email: ");
        nuevoCliente.email = Console.ReadLine();
        
        Console.Write("Teléfono: ");
        nuevoCliente.telefono = Console.ReadLine();
        
        clientes.Add(nuevoCliente);
        Console.WriteLine("Cliente registrado exitosamente.");
    }
    
    public static void ListarClientes()
    {
        Console.WriteLine("--- LISTA DE CLIENTES ---");
        if (clientes.Count == 0)
        {
            Console.WriteLine("No hay clientes registrados.");
            return;
        }
        foreach (var cliente in clientes)
        {
            Console.WriteLine($"ID: {cliente.id}, Nombre: {cliente.nombre}, Identificación: {cliente.identificacion}, Email: {cliente.email}, Teléfono: {cliente.telefono}");
        }
    }
    
    public static void EditarCliente()
    {
        Console.Write("Ingresa el ID del cliente a editar: ");
        if (int.TryParse(Console.ReadLine(), out int id))
        {
            var clienteAEditar = clientes.FirstOrDefault(c => c.id == id);
            if (clienteAEditar != null)
            {
                Console.WriteLine($"Editando: {clienteAEditar.nombre}");
                Console.Write("Nuevo nombre (dejar en blanco para no cambiar): ");
                string nuevoNombre = Console.ReadLine();
                if (!string.IsNullOrEmpty(nuevoNombre))
                {
                    clienteAEditar.nombre = nuevoNombre;
                }
                
                Console.Write("Nuevo email (dejar en blanco para no cambiar): ");
                string nuevoEmail = Console.ReadLine();
                if (!string.IsNullOrEmpty(nuevoEmail))
                {
                    clienteAEditar.email = nuevoEmail;
                }
                
                Console.WriteLine("Cliente actualizado exitosamente.");
            }
            else
            {
                Console.WriteLine("Cliente no encontrado.");
            }
        }
        else
        {
            Console.WriteLine("ID no válido.");
        }
    }

    public static void EliminarCliente()
    {
        Console.Write("Ingresa el ID del cliente a eliminar: ");
        if (int.TryParse(Console.ReadLine(), out int id))
        {
            var clienteAEliminar = clientes.FirstOrDefault(c => c.id == id);
            if (clienteAEliminar != null)
            {
                clientes.Remove(clienteAEliminar);
                Console.WriteLine("Cliente eliminado exitosamente.");
            }
            else
            {
                Console.WriteLine("Cliente no encontrado.");
            }
        }
        else
        {
            Console.WriteLine("ID no válido.");
        }
    }

    public static void GestionTiquetes()
    {
        Console.Clear();
        Console.WriteLine("--- GESTIÓN DE TIQUETES ---");
        Console.WriteLine("1. Registrar compra de tiquete");
        Console.WriteLine("2. Listar tiquetes vendidos");
        Console.WriteLine("3. Editar compra");
        Console.WriteLine("4. Eliminar compra");
        Console.Write("Selecciona una opción: ");
        string opcion = Console.ReadLine();
        
        switch (opcion)
        {
            case "1":
                RegistrarCompraTiquete();
                break;
            case "2":
                ListarTiquetesVendidos();
                break;
            case "3":
                EditarCompra();
                break;
            case "4":
                EliminarCompra();
                break;
            default:
                Console.WriteLine("Opción no válida.");
                break;
        }
    }

    public static void RegistrarCompraTiquete()
    {
        Console.WriteLine("--- REGISTRO DE COMPRA DE TIQUETE ---");
        ListarConciertos();
        Console.Write("Ingresa el ID del concierto para la compra: ");
        if (!int.TryParse(Console.ReadLine(), out int idConcierto) || conciertos.FirstOrDefault(c => c.id == idConcierto) == null)
        {
            Console.WriteLine("ID de concierto no válido.");
            return;
        }

        ListarClientes();
        Console.Write("Ingresa el ID del cliente que realiza la compra: ");
        if (!int.TryParse(Console.ReadLine(), out int idCliente) || clientes.FirstOrDefault(c => c.id == idCliente) == null)
        {
            Console.WriteLine("ID de cliente no válido.");
            return;
        }

        Console.Write("Cantidad de tiquetes a comprar: ");
        if (!int.TryParse(Console.ReadLine(), out int cantidad) || cantidad <= 0)
        {
            Console.WriteLine("Cantidad no válida.");
            return;
        }
        
        var nuevaCompra = new Compra
        {
            id = compraIdCounter++,
            idConcierto = idConcierto,
            idCliente = idCliente,
            cantidadTiquetes = cantidad,
            fechaCompra = DateTime.Now
        };
        
        compras.Add(nuevaCompra);
        Console.WriteLine("Compra registrada exitosamente.");
    }
    
    public static void ListarTiquetesVendidos()
    {
        Console.WriteLine("--- LISTA DE TIQUETES VENDIDOS ---");
        if (compras.Count == 0)
        {
            Console.WriteLine("No hay compras registradas.");
            return;
        }
        foreach (var compra in compras)
        {
            var cliente = clientes.FirstOrDefault(c => c.id == compra.idCliente);
            var concierto = conciertos.FirstOrDefault(c => c.id == compra.idConcierto);
            Console.WriteLine($"ID Compra: {compra.id}, Cliente: {(cliente != null ? cliente.nombre : "Desconocido")}, Concierto: {(concierto != null ? concierto.nombre : "Desconocido")}, Cantidad: {compra.cantidadTiquetes}, Fecha: {compra.fechaCompra.ToShortDateString()}");
        }
    }

    public static void EditarCompra()
    {
        Console.Write("Ingresa el ID de la compra a editar: ");
        if (!int.TryParse(Console.ReadLine(), out int id))
        {
            Console.WriteLine("ID no válido.");
            return;
        }

        var compraAEditar = compras.FirstOrDefault(c => c.id == id);
        if (compraAEditar == null)
        {
            Console.WriteLine("Compra no encontrada.");
            return;
        }

        Console.WriteLine($"Editando compra ID: {compraAEditar.id}");
        Console.Write("Nueva cantidad de tiquetes (dejar en blanco para no cambiar): ");
        string nuevaCantidadStr = Console.ReadLine();
        if (!string.IsNullOrEmpty(nuevaCantidadStr))
        {
            if (int.TryParse(nuevaCantidadStr, out int nuevaCantidad) && nuevaCantidad > 0)
            {
                compraAEditar.cantidadTiquetes = nuevaCantidad;
                Console.WriteLine("Cantidad de tiquetes actualizada.");
            }
            else
            {
                Console.WriteLine("Cantidad no válida, no se realizó el cambio.");
            }
        }
    }

    public static void EliminarCompra()
    {
        Console.Write("Ingresa el ID de la compra a eliminar: ");
        if (!int.TryParse(Console.ReadLine(), out int id))
        {
            Console.WriteLine("ID no válido.");
            return;
        }
        var compraAEliminar = compras.FirstOrDefault(c => c.id == id);
        if (compraAEliminar != null)
        {
            compras.Remove(compraAEliminar);
            Console.WriteLine("Compra eliminada exitosamente.");
        }
        else
        {
            Console.WriteLine("Compra no encontrada.");
        }
    }

    public static void MostrarHistorialCompras()
    {
        Console.WriteLine("--- HISTORIAL DE COMPRAS ---");
        ListarClientes();
        Console.Write("Ingresa el ID del cliente para ver su historial: ");
        if (!int.TryParse(Console.ReadLine(), out int idCliente))
        {
            Console.WriteLine("ID de cliente no válido.");
            return;
        }
        
        var historial = compras.Where(c => c.idCliente == idCliente).ToList();
        
        if (historial.Count == 0)
        {
            Console.WriteLine("El cliente no tiene compras registradas.");
            return;
        }
        
        foreach (var compra in historial)
        {
            var concierto = conciertos.FirstOrDefault(c => c.id == compra.idConcierto);
            Console.WriteLine($"- Compra ID: {compra.id}, Concierto: {(concierto != null ? concierto.nombre : "Desconocido")}, Cantidad: {compra.cantidadTiquetes}, Fecha: {compra.fechaCompra.ToShortDateString()}");
        }
    }
    
    public static void ConsultasAvanzadas()
    {
        Console.Clear();
        Console.WriteLine("--- CONSULTAS AVANZADAS (LINQ) ---");
        Console.WriteLine("1. Consultar conciertos por ciudad");
        Console.WriteLine("2. Consultar conciertos por rango de fechas");
        Console.WriteLine("3. Consultar el concierto con más tiquetes vendidos");
        Console.WriteLine("4. Consultar ingresos totales de un concierto");
        Console.WriteLine("5. Consultar cliente con más compras realizadas");
        Console.Write("Selecciona una opción: ");
        string opcion = Console.ReadLine();
        
        switch (opcion)
        {
            case "1":
                ConsultarConciertosPorCiudad();
                break;
            case "2":
                ConsultarConciertosPorFechas();
                break;
            case "3":
                ConsultarConciertoMasVendido();
                break;
            case "4":
                ConsultarIngresosConcierto();
                break;
            case "5":
                ConsultarClienteMasCompras();
                break;
            default:
                Console.WriteLine("Opción no válida.");
                break;
        }
    }
    
    public static void ConsultarConciertosPorCiudad()
    {
        Console.Write("Ingresa la ciudad a buscar: ");
        string ciudad = Console.ReadLine();
        var conciertosEnCiudad = conciertos.Where(c => c.ciudad.ToLower() == ciudad.ToLower()).ToList();
        
        if (conciertosEnCiudad.Count == 0)
        {
            Console.WriteLine($"No se encontraron conciertos en {ciudad}.");
            return;
        }
        
        Console.WriteLine($"--- CONCIERTOS EN {ciudad.ToUpper()} ---");
        foreach (var concierto in conciertosEnCiudad)
        {
            Console.WriteLine($"- ID: {concierto.id}, Nombre: {concierto.nombre}, Fecha: {concierto.fechaConcierto.ToShortDateString()}");
        }
    }

    public static void ConsultarConciertosPorFechas()
    {
        Console.Write("Ingresa la fecha de inicio (yyyy-MM-dd): ");
        if (!DateTime.TryParse(Console.ReadLine(), out DateTime fechaInicio))
        {
            Console.WriteLine("Fecha de inicio no válida.");
            return;
        }

        Console.Write("Ingresa la fecha de fin (yyyy-MM-dd): ");
        if (!DateTime.TryParse(Console.ReadLine(), out DateTime fechaFin))
        {
            Console.WriteLine("Fecha de fin no válida.");
            return;
        }

        var conciertosEnRango = conciertos.Where(c => c.fechaConcierto >= fechaInicio && c.fechaConcierto <= fechaFin).ToList();

        if (conciertosEnRango.Count == 0)
        {
            Console.WriteLine("No se encontraron conciertos en ese rango de fechas.");
            return;
        }

        Console.WriteLine("--- CONCIERTOS EN RANGO DE FECHAS ---");
        foreach (var concierto in conciertosEnRango)
        {
            Console.WriteLine($"- ID: {concierto.id}, Nombre: {concierto.nombre}, Ciudad: {concierto.ciudad}, Fecha: {concierto.fechaConcierto.ToShortDateString()}");
        }
    }
    
    public static void ConsultarConciertoMasVendido()
    {
        var conciertoMasVendido = compras.GroupBy(c => c.idConcierto)
                                         .Select(g => new { ConciertoId = g.Key, TotalTiquetes = g.Sum(c => c.cantidadTiquetes) })
                                         .OrderByDescending(x => x.TotalTiquetes)
                                         .FirstOrDefault();

        if (conciertoMasVendido != null)
        {
            var concierto = conciertos.FirstOrDefault(c => c.id == conciertoMasVendido.ConciertoId);
            if (concierto != null)
            {
                Console.WriteLine($"El concierto con más tiquetes vendidos es: {concierto.nombre}");
                Console.WriteLine($"Total de tiquetes vendidos: {conciertoMasVendido.TotalTiquetes}");
            }
            else
            {
                Console.WriteLine("No se pudo encontrar el concierto. (Puede ser que se eliminó después de la compra)");
            }
        }
        else
        {
            Console.WriteLine("No hay compras registradas para determinar el concierto más vendido.");
        }
    }
    
    public static void ConsultarIngresosConcierto()
    {
        ListarConciertos();
        Console.Write("Ingresa el ID del concierto para consultar sus ingresos: ");
        if (!int.TryParse(Console.ReadLine(), out int idConcierto))
        {
            Console.WriteLine("ID no válido.");
            return;
        }
        
        var concierto = conciertos.FirstOrDefault(c => c.id == idConcierto);
        if (concierto == null)
        {
            Console.WriteLine("Concierto no encontrado.");
            return;
        }
        
        var ingresos = compras.Where(c => c.idConcierto == idConcierto)
                              .Sum(c => c.cantidadTiquetes * concierto.precio);
        
        Console.WriteLine($"Ingresos totales para el concierto '{concierto.nombre}': ${ingresos}");
    }
    
    public static void ConsultarClienteMasCompras()
    {
        var clienteMasCompras = compras.GroupBy(c => c.idCliente)
                                       .Select(g => new { ClienteId = g.Key, TotalCompras = g.Count() })
                                       .OrderByDescending(x => x.TotalCompras)
                                       .FirstOrDefault();

        if (clienteMasCompras != null)
        {
            var cliente = clientes.FirstOrDefault(c => c.id == clienteMasCompras.ClienteId);
            if (cliente != null)
            {
                Console.WriteLine($"El cliente que ha realizado más compras es: {cliente.nombre}");
                Console.WriteLine($"Total de compras realizadas: {clienteMasCompras.TotalCompras}");
            }
            else
            {
                Console.WriteLine("No se pudo encontrar el cliente. (Puede ser que se eliminó después de la compra)");
            }
        }
        else
        {
            Console.WriteLine("No hay compras registradas para determinar el cliente con más compras.");
        }
    }
	
}